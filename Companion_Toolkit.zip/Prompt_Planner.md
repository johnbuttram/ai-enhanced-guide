# Prompt Planner

Use this document to record your best AI prompts for optimization, troubleshooting, and tweaking your system.

---

## System Specs
- CPU:
- GPU:
- RAM:
- Storage:

---

## Prompt Template
**Goal:**  
(What are you trying to fix or improve?)

**Prompt Used:**  
(Paste your ChatGPT prompt here)

**Result / Feedback:**  
(Did it work? What was the response?)

**Next Action / Tweaks:**  
(What will you try next?)

---

## Example
**Goal:** Reduce stuttering in Elden Ring  
**Prompt:** What are the best settings for Elden Ring on an RTX 3060 + Ryzen 5600?  
**Result:** Helped lower shadows and disable motion blur, gained 15 FPS  
**Next:** Test with updated drivers and log FPS
